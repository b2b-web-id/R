library(survival)

# The brier score and the RTTR algorithm should agree
